library(ggplot2)
library(mgcv)
library(raster)
library(ggeffects)

# -------------------------------------------------------------------------
# Summary model -----------------------------------------------------------
# -------------------------------------------------------------------------

# Create folders to save results 

dir.create("Results", recursive = TRUE)

# Here we fit the aerobic scope data of the mayan octopus

data <- read.csv('Database/Thermal_metabolic_scope_data.csv') # Read data
mod  <- gam((Thermal_metabolic_scope) ~ s(Temperature, k = 4), data = data, family = "Gamma")
capture.output(summary(mod), file = 'Results/Results_Thermal_scope_gam.txt')


# -------------------------------------------------------------------------
# Residuals ---------------------------------------------------------------
# -------------------------------------------------------------------------

pdf("Results/Residuals_GAM_gamma.pdf")

par(mfrow = c(2,2),
    mar = c(4,4,4,4))


# Histogram

hist(residuals(mod),  xlab = "Residuals",
     main = "Histogram of residuals")
box()

# qnorm

qqnorm(residuals(mod), pch = 16, col = "black")
qqline(residuals(mod), col = "red")

# Residuals vs Linear prediction

res <- residuals(mod) 
plot(fitted(mod), res, pch = 16, col = "black", 
     ylab = "Residuals", xlab = "Linear predictor",
     main = "Residuals vs linear prediction")
abline(h = 0, col = "red")

# Observed vs fitted values

res <- residuals(mod) 
plot(fitted(mod), data$Thermal_metabolic_scope, pch = 16, col = "black", 
     ylab = "Response", xlab = "Fitted values",
     main = "Observed vs fitted values")

dev.off()


# -------------------------------------------------------------------------
# Predict -----------------------------------------------------------------
# -------------------------------------------------------------------------

# Predict data

Pre_Temp           <- as.data.frame(seq(13,33, length = 50))
colnames(Pre_Temp) <- 'Temperature'
pred               <- predict(mod, Pre_Temp, se.fit = TRUE, type = "response")
pred               <- (data.frame(pred))

# -------------------------------------------------------------------------
# Calculate standard error of the model -----------------------------------
# -------------------------------------------------------------------------

tem <- Pre_Temp
fit <- data.frame(pred$fit)
lwr <- data.frame(pred$fit - pred$se.fit)
upr <- data.frame(pred$fit + pred$se.fit)
gam_pre <- cbind(tem, fit, lwr, upr)

colnames(gam_pre)     <- c('Temperature', 'Pred', 'Lower', 'Upper')
gam_pre$Aerobic_scope <- data$Aerobic_scope
gam_pre$Temp          <- data$Temp

# -------------------------------------------------------------------------
# Plot and save results of the model --------------------------------------
# -------------------------------------------------------------------------

q <-  ggplot(gam_pre, aes(Temperature,Pred)) + geom_line(aes(Temperature,Pred), lwd = 1.1, color = "red") +
  geom_ribbon(aes(ymin=Lower,ymax=Upper), alpha=0.1, fill = 'red') + 
  labs(x = "Temperature (°C)", y = "Thermal metabolic scope (mg/O2h/kg)") + theme_bw()

# Save fitted model

pdf('Results/GAM_model_TMS.pdf', width = 7)
q  
dev.off()

# -------------------------------------------------------------------------
# Function to project the model -------------------------------------------
# -------------------------------------------------------------------------

# Run the following function (Temp_fit) to later project the model

Temp_fit <- function(stack, folder_name, mod, ...){
  
  options(warn=-1)
  newdir <- paste0('Results/', folder_name)
  dir.create(newdir, recursive = TRUE)
  
  # Projection
  
  for(i in 1:length(names(stack))){
    
    # Suitability maps
    f   <- gsub(".", "-", names(stack[[i]]), fixed = TRUE)
    f   <- paste0(f, '.tif')
    ras <- stack[[i]] 
    names(ras)   <- 'Temperature'
    pre <- (predict(ras, mod, type = "response"))
    writeRaster(pre, filename = paste0(newdir,'/',f), overwrite=TRUE) 
  }
  options(warn=0)
}

# -------------------------------------------------------------------------
# Project model to environmental data -------------------------------------
# -------------------------------------------------------------------------

sta <- stack(list.files('Environmental/Model/Fishery_region/', 
                        full.names = TRUE))

# In the function you need to specify a stack of rasters, the name of the folder
# where results are going to be saved and the name of the fitted model

Temp_fit(sta, 'Thermal_metabolic_scope_Yucatan', mod)




