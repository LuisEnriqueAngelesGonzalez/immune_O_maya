library(lme4)
library(car)
library(MuMIn)
library(sjPlot)
library(effects)
# -------------------------------------------------------------------------
# Mixed linear model ------------------------------------------------------
# -------------------------------------------------------------------------

data  <- read.csv("Results/Field_thermal_metabolic_scope_immune_system.csv")

# Combine factors, i.e., date and zone

data$combined_group <- interaction(data$Date, data$Zone)

# THC ---------------------------------------------------------------------

mod_1 <-  lme4::lmer(log(THC) ~ Thermal_Metabolic_scope + (1|combined_group), data = data)
capture.output(Anova(mod_1), file = 'Results/P_value_mod_1.txt')
capture.output(r.squaredGLMM(mod_1), file = 'Results/R_squared_mod_1.txt')





# Hemag -------------------------------------------------------------------

mod_2 <- lme4::lmer(Hemag ~ Thermal_Metabolic_scope + (1 | combined_group), data = data)
capture.output(Anova(mod_2), file = 'Results/P_value_mod_2.txt')
capture.output(r.squaredGLMM(mod_2), file = 'Results/R_squared_mod_2.txt')


# Lyzoz -------------------------------------------------------------------

mod_3 <- lme4::lmer(log(Lyzoz) ~ Thermal_Metabolic_scope + (1 | combined_group), data = data)
capture.output(Anova(mod_3), file = 'Results/P_value_mod_3.txt')
capture.output(r.squaredGLMM(mod_3), file = 'Results/R_squared_mod_3.txt')


# Phens -------------------------------------------------------------------

mod_4 <- lme4::lmer(log(PHENsys) ~ Thermal_Metabolic_scope + (1 | combined_group), data = data)
capture.output(Anova(mod_4), file = 'Results/P_value_mod_4.txt')
capture.output(r.squaredGLMM(mod_4), file = 'Results/R_squared_mod_4.txt')

mod_4 <- glmmPQL((PHENsys) ~ Thermal_Metabolic_scope, random = ~ 1|combined_group, data = data,
        family = quasipoisson)

summary(mod_4)


# -------------------------------------------------------------------------
# Save Diagnostic ---------------------------------------------------------
# -------------------------------------------------------------------------

# THC ---------------------------------------------------------------------

pdf("Results/Assumptions_LMM_THC.pdf",
    width = 9)

par(mfrow = c(2,2),
    mar = c(4,4,4,4))


# Histogram

hist(residuals(mod_1),  xlab = "Residuals",
     main = "Histogram of residuals")
box()

# qnorm

qqnorm(residuals(mod_1), pch = 16, col = "black")
qqline(residuals(mod_1), col = "red")

# Residuals vs Linear prediction

res <- residuals(mod_1) 
plot(fitted(mod_1), res, pch = 16, col = "black", 
     ylab = "Residuals", xlab = "Linear predictor",
     main = "Residuals vs linear prediction")
abline(h = 0, col = "red")

# Observed vs fitted values

res <- residuals(mod_1) 
plot(fitted(mod_1), data$THC, pch = 16, col = "black", 
     ylab = "Response", xlab = "Fitted values",
     main = "Observed vs fitted values")

dev.off()

# Hemag -------------------------------------------------------------------

pdf("Results/Assumptions_LMM_Hemag.pdf",
    width = 9)

par(mfrow = c(2,2),
    mar = c(4,4,4,4))

# Histogram

hist(residuals(mod_2),  xlab = "Residuals",
     main = "Histogram of residuals")
box()

# qnorm

qqnorm(residuals(mod_2), pch = 16, col = "black")
qqline(residuals(mod_2), col = "red")

# Residuals vs Linear prediction

res <- residuals(mod_2) 
plot(fitted(mod_2), res, pch = 16, col = "black", 
     ylab = "Residuals", xlab = "Linear predictor",
     main = "Residuals vs linear prediction")
abline(h = 0, col = "red")

# Observed vs fitted values

res <- residuals(mod_2) 
plot(fitted(mod_2), data$Hemag, pch = 16, col = "black", 
     ylab = "Response", xlab = "Fitted values",
     main = "Observed vs fitted values")

dev.off()

# Lyzoz -------------------------------------------------------------------

pdf("Results/Assumptions_LMM_Lyzoz.pdf",
    width = 9)

par(mfrow = c(2,2),
    mar = c(4,4,4,4))

# Histogram

hist(residuals(mod_3),  xlab = "Residuals",
     main = "Histogram of residuals")
box()

# qnorm

qqnorm(residuals(mod_3), pch = 16, col = "black")
qqline(residuals(mod_3), col = "red")

# Residuals vs Linear prediction

res <- residuals(mod_3) 
plot(fitted(mod_3), res, pch = 16, col = "black", 
     ylab = "Residuals", xlab = "Linear predictor",
     main = "Residuals vs linear prediction")
abline(h = 0, col = "red")

# Observed vs fitted values

res <- residuals(mod_3) 
plot(fitted(mod_3), data$Lyzoz, pch = 16, col = "black", 
     ylab = "Response", xlab = "Fitted values",
     main = "Observed vs fitted values")

dev.off()

# PhenSys -----------------------------------------------------------------

pdf("Results/Assumptions_LMM_Phensys.pdf",
    width = 9)

par(mfrow = c(2,2),
    mar = c(4,4,4,4))

# Histogram

hist(residuals(mod_4),  xlab = "Residuals",
     main = "Histogram of residuals")
box()

# qnorm

qqnorm(residuals(mod_4), pch = 16, col = "black")
qqline(residuals(mod_4), col = "red")

# Residuals vs Linear prediction

res <- residuals(mod_4) 
plot(fitted(mod_4), res, pch = 16, col = "black", 
     ylab = "Residuals", xlab = "Linear predictor",
     main = "Residuals vs linear prediction")
abline(h = 0, col = "red")

# Observed vs fitted values

res <- residuals(mod_4) 
plot(fitted(mod_4), data$PHENsys, pch = 16, col = "black", 
     ylab = "Response", xlab = "Fitted values",
     main = "Observed vs fitted values")

dev.off()

# -------------------------------------------------------------------------
# Plot the models ---------------------------------------------------------
# -------------------------------------------------------------------------

p1 <- sjPlot::plot_model(mod_1, type =  "pred") + ylab("Total hemocytes count (Cell/m³)") +
      theme_bw() + rremove("xlab") + labs(title="")

p2 <- sjPlot::plot_model(mod_2, type =  "pred") + ylab("Hemagglutination (titer)") +
  theme_bw() + rremove("xlab")  + labs(title="")


p3 <- sjPlot::plot_model(mod_3, type =  "pred") + ylab("Lysozyme (U/ml)") +
  theme_bw() + rremove("xlab")  + labs(title="")

p4 <- sjPlot::plot_model(mod_4, type =  "pred") + ylab("Phenoloxidase activity system (OD)") +
  theme_bw() + rremove("xlab")  + labs(title="")


ara <- ggarrange(p1, p2,
          p3, p4, nrow = 2, ncol = 2) 


pdf("Results/LMM_immune_system.pdf")
annotate_figure(ara,
                bottom = text_grob("Thermal metabolic scope (mg/O2h/kg)"))
dev.off()
