library(dplyr)
library(vegan)
library(ggpubr)
library(viridis)

# -------------------------------------------------------------------------
# Create quantiles --------------------------------------------------------
# -------------------------------------------------------------------------

# Read data 

data <- read.csv("Results/Field_thermal_metabolic_scope_immune_system.csv")

# Divide data by quantiles. Thermal_Metabolic_scope represents the thermal
# metabolic scope value matched according to the date of sampling and the region 

Quantile_limits <- quantile(data$Thermal_Metabolic_scope, seq(0, 1, 1/4), na.rm = TRUE)
data$Quantiles  <- cut(data$Thermal_Metabolic_scope, Quantile_limits, c('Quantile 1', 'Quantile 2', 'Quantile 3',
                                                    'Quantile 4'), include.lowest = TRUE)


# -------------------------------------------------------------------------
# nMDS --------------------------------------------------------------------
# -------------------------------------------------------------------------

# The function pdf is to save the figures, the pdf functions stop when 
# dev.off is run

pdf('Results/nmds.pdf')

# Scale the immunological data

phy_nmds <- scale(data[,c(5:8)])

# Run the nmds 

phy_nmds   <- metaMDS(phy_nmds, distance = 'euclidean', k = 2, trymax = 10000, autotransform = FALSE) 

# Plot the results 

plot(phy_nmds, type='n', xlab = '', ylab = '', main = 'nMDS', las = 1)
abline(h = 0,  v = 0, lty = 2)

points(phy_nmds, pch= 21,
       bg=ifelse(data$Quantiles=='Quantile 1', viridis(4)[4], 
                 ifelse(data$Quantiles=='Quantile 2', viridis(4)[3],
                        ifelse(data$Quantiles=='Quantile 3', viridis(4)[2],
                               ifelse(data$Quantiles=='Quantile 4', viridis(4)[1],NA)))), cex = 1.15)


colors <- ifelse(data$Quantiles=='Quantile 1', viridis(4)[4], 
                 ifelse(data$Quantiles=='Quantile 2', viridis(4)[3],
                        ifelse(data$Quantiles=='Quantile 3', viridis(4)[2],
                               ifelse(data$Quantiles=='Quantile 4', viridis(4)[1],NA))))


# text(Fish_nmds$points[,1], Fish_nmds$points[,2], labels = Fish$Season)


for(i in unique(data$Quantiles)) {
  ordiellipse(phy_nmds$point[grep(i,data$Quantiles),],draw="polygon",
              groups=data$Quantiles[data$Quantiles==i],col=colors[grep(i,data$Quantiles)],label=F, alpha = 50, 
              conf  = 0.95)}

legend('topleft', inset = 0, 'Stress = 0.18', bty = 'n', cex = 1.15)


legend("bottomleft", inset=.0, 
       legend = c('Quantile 1', 'Quantile 2','Quantile 3', 'Quantile 4'), 
       horiz=FALSE, cex = 1, pch = c(16),
       col = c( viridis(4)[4],  viridis(4)[3],  viridis(4)[2], viridis(4)[1]))
box()

dev.off() # pdf function stop

# -------------------------------------------------------------------------
# Boxplots ----------------------------------------------------------------
# -------------------------------------------------------------------------


# THC ---------------------------------------------------------------------

THC <- ggboxplot(data, "Quantiles", "THC",
                 fill = "Quantiles", palette = c(viridis(4)[4], viridis(4)[3],
                                                 viridis(4)[2], viridis(4)[1])) + 
  ylab('Total hemocytes count (Cell/mm³)') +
  xlab('Quantiles of aerobic scope ') + 
  rremove('x.text') + rremove('x.ticks') + 
  stat_summary(fun.data = function(x) data.frame(y=0, label = paste("Median=",round(median(x)))), geom="text")


# HEMAG -------------------------------------------------------------------


HEM <- ggboxplot(data, "Quantiles", "Hemag",
                 fill = "Quantiles", palette = c(viridis(4)[4], viridis(4)[3],
                                                 viridis(4)[2], viridis(4)[1])) + 
  ylab('Hemagglutination (titer)') +
  xlab('Quantiles of aerobic scope ') + rremove('x.text') + rremove('x.ticks') + 
  stat_summary(fun.data = function(x) data.frame(y=0, label = paste("Median=",round(median(x)))), geom="text")


# Lyzosome ---------------------------------------------------------------------

LYZ <- ggboxplot(data, "Quantiles", "Lyzoz",
                 fill = "Quantiles", palette = c(viridis(4)[4], viridis(4)[3],
                                                 viridis(4)[2], viridis(4)[1])) + 
  ylab('Lysozyme (U/ml)') +
  xlab('Quantile of aerobic scope ') + rremove('x.text') + rremove('x.ticks') + 
  stat_summary(fun.data = function(x) data.frame(y=0, label = paste("Median=",round(median(x)))), geom="text")



# Phenolsy ---------------------------------------------------------------------


PHEs <- ggboxplot(data, "Quantiles", "PHENsys",
                  fill = "Quantiles", palette = c(viridis(4)[4], viridis(4)[3],
                                                  viridis(4)[2], viridis(4)[1])) + 
  ylab('Phenoloxidase activity system (OD 490 nm)') +
  xlab('Quantile of aerobic scope ') + rremove('x.text') + rremove('x.ticks') + 
  stat_summary(fun.data = function(x) data.frame(y=0, label = paste("Median=",round(median(x), 2))), geom="text")

# Save boxplot

pdf('Results/boxplot.pdf', width = 12)

ggarrange(THC, HEM, LYZ, PHEs,
          common.legend = TRUE)

dev.off()

# -------------------------------------------------------------------------
# Correlationships --------------------------------------------------------
# -------------------------------------------------------------------------

capture.output(cor.test(data$Thermal_Metabolic_scope, data$THC), file = 'Results/Cor_TMS_THC.txt')
capture.output(cor.test(data$Thermal_Metabolic_scope, data$Lyzoz), file = 'Results/Cor_TMS_Lyzoz.txt')
capture.output(cor.test(data$Thermal_Metabolic_scope, data$PHENsys), file = 'Results/Cor_TMS_PHENsys.txt')
capture.output(cor.test(data$Thermal_Metabolic_scope, data$Hemag), file = 'Results/Cor_TMS_Hemag.txt')





