library(sf)
library(raster)

# -------------------------------------------------------------------------
# Match aerobic scope data with zones -------------------------------------
# -------------------------------------------------------------------------

data         <- read.csv('Database/Immunological_data.csv')
data$Date    <- as.Date(data$Date, format = "%Y-%m-%d")
data$Date    <- gsub('.{3}$', '', data$Date) # Delete day data
data         <- data[order(data$Date),]
labelTime    <- unique(data$Date)

# -------------------------------------------------------------------------
# Read shapefiles ---------------------------------------------------------
# -------------------------------------------------------------------------

shp   <- list.files(path = 'Shapefiles/Zones/', pattern = '.shp', full.names = TRUE)
shape <- list.files(path = 'Shapefiles/Zones/', pattern = '.shp', full.names = FALSE)
shape <- gsub(".shp", "", shape)

# -------------------------------------------------------------------------
# Match aerobic scope data with the corresponding octopus observat --------
# -------------------------------------------------------------------------

# The loop matches the average thermal metabolic scope of each zone with octopus samples.

for(i in seq_along(shp)){
  
  input         <- data[which(data$Zone == shape[i]), ]
  #input$Date    <- gsub('.{3}$', '', input$Date)
  reg      <- st_read(shp[i]) 
  out      <- list()
  
  for(j in seq_along(labelTime))
    try({
      
      # Select and read raster
      
      df   <- input[which(input$Date==labelTime[j]), ]
      env1 <- list.files(path ='Results/Thermal_metabolic_scope_Yucatan/', 
                         pattern = paste0(labelTime[j]), full.names = TRUE)
      env1 <- raster(env1)
      
      # Crop
      
      env1 <- crop(env1, reg)
      env1 <- cellStats(env1, median)
      out[[j]] <- cbind(df, env1)
    }, silent = TRUE)
  
  # Save dataframe
  
  sp_envir  <- plyr::ldply(out, data.frame)
  f         <- paste0('Results/', shape[i], '.csv')
  write.csv(sp_envir, file = f, row.names = FALSE)
}

# -------------------------------------------------------------------------
# Merge databases ---------------------------------------------------------
# -------------------------------------------------------------------------

# Read the databases created

a <- read.csv('Results/Zone_I.csv')
b <- read.csv('Results/Zone_II.csv')
c <- read.csv('Results/Zone_III.csv')

# Merge databases

d <- rbind(a,b,c)
colnames(d)[9] <- "Thermal_Metabolic_scope" # Change the name of the column with the results

# Save results

write.csv(d, 'Results/Field_thermal_metabolic_scope_immune_system.csv', row.names = FALSE)


