library(raster)
library(bamm)
library(geodata)



# Model -------------------------------------------------------------------

data <- read.csv('Database/Thermal_metabolic_scope_data.csv')

scale_values <- function(x){(x-min(x))/(max(x)-min(x))} # For model to run we need o relativize the values between 0 and
x_scaled     <- scale_values(data$Thermal_metabolic_scope)

data           <- cbind(data, x_scaled)
colnames(data) <- c("Temperature", "Thermal_metabolic_scope", "Scaled_Thermal_metabolic_scope")

svTransform <- function(y)
{
  n <- length(y)
  transformed <- (y * (n-1) + 0.5)/n
  return(transformed)
}

data$Scaled_Thermal_metabolic_scope <- svTransform(data$Scaled_Thermal_metabolic_scope)

# Plot model --------------------------------------------------------------

mod          <- gam(Scaled_Thermal_metabolic_scope ~ s(Temperature, k = 4), data = data,  family = "Gamma")
Temperature  <- seq(18,30,0.1)
pred         <- predict(mod, data.frame(Temperature), se.fit = TRUE, type = "response")
pred         <- cbind(pred$fit, Temperature)
per          <- pred[121,1] # Select the threshold value used for model projection

# Project model -----------------------------------------------------------


Temp_fit <- function(stack, folder_name, mod, ...){
  
  options(warn=-1)
  newdir <- paste0('Environmental/', folder_name)
  dir.create(newdir, recursive = TRUE)
  
  # Projection
  
  for(i in 1:length(names(stack))){
    
    # Suitability maps
    f   <- gsub(".", "-", names(stack[[i]]), fixed = TRUE)
    f   <- paste0(f, '.asc')
    ras <- stack[[i]] 
    names(ras)   <- 'Temperature'
    pre <- predict(ras, mod, type = "response")
    writeRaster(pre, filename = paste0(newdir,'/',f), overwrite=TRUE) 
  }
  options(warn=0)
}


# Project the model -------------------------------------------------------

sta <- stack(list.files("Environmental/Model/Fishery_region/", full.names = TRUE))
Temp_fit(sta, 'Scaled_for_simulation', mod)

# Prepare data for simulation ---------------------------------------------

sta <- stack(list.files("Environmental/Scaled_for_simulation/", pattern = "asc", full.names = TRUE))
coo <- rasterToPoints(sta[[1]]) # We need to know coordinates of pixels to seed all virtual octopus around all the Yucatan Peninsula

# Converts a niche model into a diagonal sparse matrix --------------------

sparse_mod  <- bamm::model2sparse(sta[[1]],threshold = per) # Threshold convert a continous model into a binary model


# Converts occurrence data into a sparse matrix object --------------------

occs_sparse <- bamm::occs2sparse(modelsparse = sparse_mod,
                                 occs = coo)

# Function to compute the adjacency matrix of an area  --------------------


adj_mod <- bamm::adj_mat(sparse_mod,ngbs = 2) 

# Simulate single species dispersal dynamics using the BAM framework ------

smd <- bamm::sdm_sim(set_A = sparse_mod,
                     set_M = adj_mod,
                     initial_points = occs_sparse,
                     nsteps = 2,
                     stochastic_dispersal = TRUE,
                     disp_prop2_suitability = TRUE,
                     disper_prop = 1)

sim_res <- bamm::sim2Raster(smd)
plot(sim_res)


# Pedict species distribution under suitability changes -------------------

new_preds1 <- bamm::predict(object = smd,
                            niche_layers = sta[[-1]],
                            nsteps_vec = c(2,2,2,2,2,2,
                                           2,2,2,2,2),
                            disp_prop2_suitability = TRUE,
                            animate = FALSE)




# Save results ------------------------------------------------------------

date <- c("01_January", "02_February", "03_March", "04_April", "05_May",
          "06_June", "07_July", "08_August", "09_September", "10_October", 
          "11_November", "12_December")

for(i in seq_along(1:12))
{
  nam     <- paste0("Results/", date[i], ".tif")
  sim_res <- bamm::sim2Raster(new_preds1[[i]])
  ras     <- sim_res[[2]]
  writeRaster(ras, nam)
}



# -------------------------------------------------------------------------
# Figure ------------------------------------------------------------------
# -------------------------------------------------------------------------

dat <- list.files("Results/", full.names = TRUE, pattern = ".tif")
dat <- stack(dat)
dat <- dat[[c(6,8,10,12)]]
Mex <- gadm("Mex", level=1, path="Environmental/", version="latest", resolution=1)

breakpoints <- c(0,0.5,1)
colors      <- c("#FDE725FF","#440154FF")


# -------------------------------------------------------------------------

pdf("Results/Simulation_map.pdf")

par(mfrow = c(2,2),
    mar = c(1.5,0.5,1.5,0.5))

image(dat[[1]], ylim = c(19, 23.2), xaxt = "n", yaxt = "n", 
      breaks=breakpoints,col=colors, main = "June 2010")
plot(Mex, add = TRUE, col = "lightgrey", lwd = 0.001)
box()
legend("bottomright", 
       c("Absence", "Presence"), fill= c("#FDE725FF","#440154FF"),  cex=0.8, 
       bg='white')

image(dat[[2]], ylim = c(19, 23.2), xaxt = "n", yaxt = "n", 
      breaks=breakpoints,col=colors, main = "August 2010")
plot(Mex, add = TRUE, col = "lightgrey", lwd = 0.001)
box()

image(dat[[3]], ylim = c(19, 23.2), xaxt = "n", yaxt = "n", 
      breaks=breakpoints,col=colors, main = "October 2010")
plot(Mex, add = TRUE, col = "lightgrey", lwd = 0.001)
box()

image(dat[[4]], ylim = c(19, 23.2), xaxt = "n", yaxt = "n", 
      breaks=breakpoints,col=colors, main = "December 2010")
plot(Mex, add = TRUE, col = "lightgrey", lwd = 0.001)
box()

dev.off()